#include<iostream>
using namespace std;
int main(){
	for(int i=100;i<1000;i++)
	{
		int a,b,c,A,B,C;
		a=i/100;
		b=(i-a*100)/10;
		c=i-100*a-10*b;
		A=a*a*a;
		B=b*b*b;
		C=c*c*c;
		if(i==A+B+C) cout<<i<<endl;
	}
}