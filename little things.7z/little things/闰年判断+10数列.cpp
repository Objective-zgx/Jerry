/*#include<iostream>
int main(){
	int n;
	std::cin>>n;
	if(n%4==0)
	{
		if(n%400==0)
			std::cout<<"yes";
		else if(n%100!=0)
			std::cout<<"yes";
		else std::cout<<"no";
	}
	else std::cout<<"no";
}*/
#include<iostream>
using namespace std;
int main(){
	for(int a=0;a<2;a++)
			{
		for(int b=0;b<2;b++)
		{	
			for(int c=0;c<2;c++)
			{		
				for(int d=0;d<2;d++)
				{	
					for(int e=0;e<2;e++)
					{
						cout<<a<<b<<c<<d<<e<<endl;
					}
	}
	}
	}
	}
}