#include<iostream>
#include<stdio.h>
#include<list>
#include<math.h>
using namespace std;

void fin(char *a){
    int sum=0;
	double len=strlen(a);
	for(int i=0;i<len;i++)
	{
		if(a[i]-87>0)
		sum+=(a[i]-87)*pow(16,len-i-1);
		else
		sum+=(a[i]-48)*pow(16,len-i-1);
	}
	//cout<<sum<<endl;//16����
	int yy=1;
	list<int> re;
	while(yy){
		yy=sum%8;
		re.push_back(yy);
		sum/=8;
	}
	while(re.size())
    {
		if(*re.rbegin()!=0)cout <<*re.rbegin();
		re.pop_back();
    }
}
int main(){
	int n;
	scanf("%d\n",&n);

	char **a=new char* [n];
	for(int i=0;i<n;i++){
		a[i]=new char [6];
		gets(a[i]);
	}
	for(int i=0;i<n;i++)
	{
		fin(a[i]);
		cout<<endl;
	}
}