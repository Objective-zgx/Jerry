#include<iostream>
#include<string>
using namespace std;
int main()
{
	int m=0,h=0;
	cin>>h>>m;
	string p[60]={"zero","one","two","three","four","five","six","seven","eight","nine","ten",
		"eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty","twenty one","twenty two","twenty three"};
	p[30]="thirty";
	p[40]="forty";
	p[50]="fifty";
	if(m==0)		cout<<p[h]<<" o'clock";
	else if(m<24)	cout<<p[h]<<" "<<p[m];
	else {
		cout<<p[h]<<" ";
		cout<<p[m-m%10]<<" "<<p[m%10];
	}
}