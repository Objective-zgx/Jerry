#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	int *a= new int [n];
	for(int i=0;i<n;i++)
		cin>>a[i];
	int k;
	cin>>k;
	for(int i=0;i<n;i++)
	{
		int flag=0;
		if(k==a[i]) 
		{
			cout<<i;
			break;
			flag++;
		}
		if(flag==0&&i==n-1)cout<<-1;
	}
}
