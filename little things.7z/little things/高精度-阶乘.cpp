#include<iostream>
#include<string>
#include<math.h>
using namespace std;
int stl(int x);
const double e = 2.71828182845;
const double pi = 3.14159265358979;
int main()
{
	int n=0;//�������
	cin>>n;
	int num=stl(n);
	cout<<endl<<n<<"�Ľ׳���"<<num<<"λ"<<endl;

	int *a;
	a=new int[num];
	for(int i=0;i<num;i++)a[i]=0;
	a[0]=1;
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<stl(i);j++)
		{
			a[j]=a[j]*i;
		}
		for(int k=0;k<stl(i);k++)
		{
			if(a[k]>=10)
			{	
				//��λ
				a[k+1]=(a[k]-a[k]%10)/10+a[k+1];
				a[k]=a[k]%10;			
			}
		}
		
	}
	for(int i=stl(n);i>0;i--)
	{
		cout<<a[i-1];
	}
}
//����λ��-˹���ֹ�ʽ
int stl(int n)
{
	int num=1;
	
	if(n!=0&&n!=1)
		num=0.5*log10(2*pi*n)+n*log10(double(n))-n*log10(e)+1;
	return num;
}