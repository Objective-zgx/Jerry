#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
int main(){
	char a[100],b[100];
	gets(a);
	gets(b);
	int le=strlen(a)>strlen(b)?strlen(a):strlen(b),len=le+1;
	int len1= strlen(a)<strlen(b)?strlen(a):strlen(b);
	int *result=new int [len];
	for(int i=0;i<len;i++)
	{
		if(i<=len1)
			result[i]=a[strlen(a)-i]+b[strlen(b)-i]-96;
		if(i>len1)
		{
			if(strlen(a)>=strlen(b))
			result[i]=a[strlen(a)-i]-48;
			else
			result[i]=b[strlen(b)-i]-48;

		}
	}
	for(int i=0;i<len;i++){
		if(result[i]>9&&i<len-1)
			{
				result[i+1]+=result[i]/10;
				result[i]=result[i]%10;
			}
		if(result[i]>9&&i==len-1)
			{
				result[i]=result[i]%10;
				result[len]=1;
			}
	}
	for(int i=len;i>0;i--)
	{	
		if(result[i]>=0)
			cout<<result[i];
	}
}