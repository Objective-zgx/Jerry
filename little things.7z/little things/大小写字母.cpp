#include<stdio.h>
int main(){
	char c1,c2;
	/******FILL**********/
	c1=getchar();;
	printf("%c,%d\n",c1,c1);
	/******FILL**********/
	c2=c1+'A'-97;
	printf("%c,%d\n",c2,c2);
	printf("%c",'A');
}