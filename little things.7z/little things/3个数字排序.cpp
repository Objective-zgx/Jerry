#include<iostream>
using namespace std;
int main(){
	int a,b,c;
	cin>>a>>b>>c;
	if(a<b)
	{
		int t=a;
		a=b;
		b=t;
	}	
if(a<c)
	cout<<c<<a<<b;
else if(a>c){
		if(b<=c)
			cout<<a<<c<<b;
		else if(b>c)
			cout<<a<<b<<c;
		}
else cout<<a<<b<<c;

}