#include<iostream>
#include<list>
//#include<math.h>
using namespace std;
list<int> l; 
bool f(int a){
	bool flag=false;
	for(int i=2;i<a;i++)
	{
		
		if(a==2) flag=false;
		else if(a%i==0){
			flag=true;
			break;
		}
		if(i==a-1&&a%i!=0)
			flag= false;
	}
	return flag;
}
void fun(int a){
	for(int i=2;i<a;i++)
		{
			if(a%i==0) {
				if(f(i)) 
					fun(i);
				else l.push_front(i);
				
				int t=a/i;
				if(f(t)){
				fun(t);
				}
				else
					l.push_front(t);
				break;
			}
	}
}

int main(){
	int a,b;
	cin>>a>>b;
	for(int i=a;i<=b;i++)
	{
		if(f(i))
		{
			fun(i);
			cout<<i<<"=";
		}
		else cout<<i<<"="<<i;
		while(!l.empty())
		{
			cout<<*l.begin();
			l.pop_front();
			if(!l.empty())
			cout<<"*";
		}
		cout<<endl;
	}
}