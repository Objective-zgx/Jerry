#include<iostream>
using namespace std;
int main()
{
	int n,F[10000000];
	F[0]=1;F[1]=1;
	for(int i=2;i<10000000;i++)
	{
		F[i]=(F[i-1]+F[i-2])%10007;
	}
	cin>>n;
	cout<<F[n-1];
}