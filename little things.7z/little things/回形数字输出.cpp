#include<iostream>
using namespace std;
struct per{
	int num;
	int sign;
};
int main(){
	int m,n;
	cin>>m>>n;
	per **p=new per* [m];
	for(int i=0;i<m;i++)
	{
		p[i]=new per [n];
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			cin>>p[i][j].num;
			p[i][j].sign=0;
		}
	}
	int sum=0;//��������
	int a=0,b=0;//������� 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16
	while(sum!=m*n){
		//��
		while(a<m&&p[a][b].sign==0)
		{
			cout<<p[a][b].num<<" ";
			p[a][b].sign=1;
			sum++;
			a++;			
		}
		//����ϸ���һ��+1��a���ϱ߶����1
		a--;b++;
		//->
		while(b<n&&p[a][b].sign==0)
		{
			cout<<p[a][b].num<<" ";
			p[a][b].sign=1;
			sum++;
			b++;
		}
		//������һ�У�a--
		a--;b--;
		//��
		while(a>=0&&p[a][b].sign==0)
		{
			cout<<p[a][b].num<<" ";
			p[a][b].sign=1;
			sum++;
			a--;
		}
		a++;b--;
		//  <-
		while(b>=0&&p[a][b].sign==0)
		{
			cout<<p[a][b].num<<" ";
			p[a][b].sign=1;
			sum++;
			b--;
		}
		a++;b++;
	}
	return 0;
}