#include<iostream>
#include<stdio.h>
#include<string>
using namespace std;
int main(){
	char p[11];
	gets(p);
	int len=strlen(p);
	string name[15]={"ling","yi","er","san","si","wu","liu","qi","ba","jiu","shi","bai","qian","wan","yi"};
	int l=len,y=0,t=1;
	for(int i=0;i<len;i++){
		y=p[i]-48;
		if((t+y)!=0&&!((len-i)==5&&y==0)){
			t=y;
			cout<<name[y]<<" ";
		}
		if(y){
		if((len-i)%4==0)
			cout<<name[12]<<" ";
		else if((len-i)%4==3)
			cout<<name[11]<<" ";
		else if((len-i)%4==2)
			cout<<name[10]<<" ";
		}
		if(len-i==5)
			cout<<name[13]<<" ";
		else if(len-i==9)
			cout<<name[14]<<" ";
	}
}