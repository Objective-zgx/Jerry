#include <iostream>
#include<stdio.h>

struct node{
	double x;
	int num;//·��ֵ��0��1
	node *ln;
	node *rn;
};
using namespace std;
int main(int argc, char *argv[]) {
	

	int a;
	double *p=new double[a];
	for(int i=0;i<a;i++)
		cin>>p[i];
	node *father;
	

	return 0;
}