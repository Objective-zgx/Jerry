#include<iostream>
#include<stdlib.h>
#include<string>
using namespace std;
//�����
int main()
{
	int n;
	cin>>n;
	string *p;
	p= new string [n];
	for(int i=0;i<n;i++)
		cin>>p[i];
	cout<<"16:"<<endl;
	for(int i=0;i<n;i++)
		cout<<p[i]<<" ";
	string *x;
	x=new string [n];
	for(int i=0;i<n;i++){
		const char *m=p[i].data();
		x[i] = (int)strtol(m, NULL, 16);
	}
	cout<<endl<<"8��"<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<x[i];
		//printf("%o\n",x[i]);
	}
}