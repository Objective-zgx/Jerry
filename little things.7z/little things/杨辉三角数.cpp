#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;n++;
	int **p=new int*[n];
	for(int i=0;i<n;i++)
	  p[i]=new int [n];
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			p[i][j]=0;
	p[0][0]=1;
	for(int i=1;i<n;i++){
		p[i][0]=1;
		for(int j=1;j<=i;j++)
		{
			
			p[i][j]=p[i-1][j-1]+p[i-1][j];
		}
	}
	for(int i=0;i<n;i++){
		int o=i;
		while(n-o-1){
			cout<<" ";
			o++;
		}
		for(int j=0;j<=i;j++)
			{
				cout<<p[i][j];
				if(i<7)cout<<"  ";
				if(i>=7&&i<=10)cout<<"  ";
		}
		cout<<endl;
	}
}