#include<iostream>
using namespace std;
int zz(int a,int b){
	int m=a<b?a:b;
	int re=0;
	for(int i=1;i<=m;i++)
	{
		if(a%i==0&&b%i==0)
			re=i;
	}
	return re;
}
int main(){
	int m,n;
	cin>>m>>n;
	int p,q;
	cin>>p>>q;
	if(m*n!=0)
	cout<<"zrf is:"<<m/zz(m,n)<<"/"<<n/zz(m,n)<<"; ";
	else if(n==0)cout<<"��ĸ����Ϊ0!!!"<<endl;
	else cout<<"0"<<endl;	
	if(p*q!=0)
	cout<<"ssh is:"<<p/zz(p,q)<<"/"<<q/zz(p,q)<<endl;
	else if(n==0)cout<<"��ĸ����Ϊ0!!!"<<endl;
	else cout<<"0"<<endl;
	
	if(m*q!=p*n)
		cout<<"(zrf==ssh) is:0;";
	else cout<<"(zrf==ssh) is:1;";
	if(m*q<p*n)cout<<"(zrf<ssh) is:1";
	if(m*q>=p*n)cout<<"(zrf<ssh) is:0";
}