#include<iostream>
using namespace std;
int main(){
	int n,m;
	cin>>n>>m;
	unsigned long long int **p=new unsigned long long int *[n];
	for(int i=0;i<n;i++)
		p[i]=new unsigned long long int [n];
	
	unsigned long long int **q=new unsigned long long int *[n];
	for(int i=0;i<n;i++)
		q[i]=new unsigned long long int [n];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cin>>p[i][j];
			q[i][j]=p[i][j];
		}
	}
	for(int i=0;i<m-1;i++)
	{
		unsigned long long int *sum;
		int j,k,z;
		sum=new unsigned long long int[n];
		for(int r=0;r<n;r++)
			sum[r]=0;
		for(j=0;j<n;j++)//j--�� 
		{
			for(k=0;k<n;k++)//k--��
			{
				for(z=0;z<n;z++)
				{
				sum[k]+=q[j][z]*p[z][k];
				//cout<<"sum["<<k<<"]=q["<<"]["<<z<<"]*p["<<z<<"]["<<k<<"]="<<sum[k]<<endl;
				}
			}
			for(int y=0;y<n;y++)
				{
					q[j][y]=sum[y];
				}
				for(int r=0;r<n;r++)
					sum[r]=0;
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++)
			{
				cout<<q[i][j];
				if(j==n-1)cout<<endl;
				else cout<<" ";
		}
	}
}