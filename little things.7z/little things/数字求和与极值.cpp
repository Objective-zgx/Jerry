#include<iostream>
using namespace std;
int max(int *p,int n){
	int temp=p[n-1];
	while(n-1){
		if(temp<p[n-2])
			temp=p[n-2];
		n--;
	}
	return temp;
}
int min(int *p,int n){
	int temp=p[n-1];
	while(n-1){
		if(temp>p[n-2])
			temp=p[n-2];
		n--;
	}
	return temp;
}
int main(){
	int n,sum=0;
	cin>>n;
	int *p=new int[n];
	for(int i=0;i<n;i++)
		{
			cin>>p[i];
			sum+=p[i];
	}
	cout<<max(p,n)<<endl;
	cout<<min(p,n)<<endl;
	cout<<sum;
}