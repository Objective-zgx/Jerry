#include<iostream>
#include<list>
using namespace std;
int main(){
	int n;
	cin>>n;
	list<int> p;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		p.push_back(x);
	}
	p.sort();int sum=0;
	for(int i=0;i<n-1;i++)
	{
		int x =p.front();
		p.pop_front();
		x += p.front();
		sum+=x;
		p.pop_front();
		p.push_front(x);
		p.sort();
	}
	cout<<sum;
}