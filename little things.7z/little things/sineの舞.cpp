#include<stdio.h>
#include<string.h>
#include<iostream>
using namespace std;
int n;

void An(int N,int t)
{
	if (N == t&&N>1)
	{
		printf("sin(%d)",N);
	}
	
	printf("sin(%d",N);
	if (N < t)
	{
		if (N%2)
		{
			printf("-");
		}
		else
		{
			printf("+");
		}
		An(N+1,t);
	}
	printf(")");
}

void Sn(int N,int t)
{
	if (N > 1)
	{
		printf("(");
		Sn(N-1,t+1);
	}
	An(1,N);
	printf("+%d",t);
	if (N != n)
		printf(")");
}

int main()
{
	scanf("%d",&n);
	Sn(n,1);
	return 0;
}
