#include<iostream>
//#include<stdlib.h>
using namespace std;
int main(){
	int m,n;
	cin>>m;cin>>n;
	char **p=new char*[m];
	for(int i=0;i<m;i++)
	{
			p[i]=new char[n];
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++)
		{
			//int t=i-j;cout<<t;
			int u=(i-j)>(j-i)?(i-j):(j-i);//cout<<u;
			if(u==0) p[i][j]='A';
			else if(u==1)p[i][j]='B';
			else if(u==2)p[i][j]='C';
			else if(u==3)p[i][j]='D';
			else if(u==4)p[i][j]='E';
			else if(u==5)p[i][j]='F';
			else if(u==6)p[i][j]='G';
			else if(u==7)p[i][j]='H';
			else if(u==8)p[i][j]='I';
			else if(u==9)p[i][j]='J';
			else if(u==10)p[i][j]='K';
			else if(u==11)p[i][j]='L';
			else if(u==12)p[i][j]='M';
			else if(u==13)p[i][j]='N';
			else if(u==14)p[i][j]='O';
			else if(u==15)p[i][j]='P';
			else if(u==16)p[i][j]='Q';
			else if(u==17)p[i][j]='R';
			else if(u==18)p[i][j]='S';
			else if(u==19)p[i][j]='T';
			else if(u==20)p[i][j]='U';
			else if(u==21)p[i][j]='V';
			else if(u==22)p[i][j]='W';
			else if(u==23)p[i][j]='X';
			else if(u==24)p[i][j]='Y';
			else if(u==25)p[i][j]='Z';
		}
		cout<<endl;
	}
		for(int i=0;i<m;i++){
			for(int j=0;j<n;j++)
			{
				cout<<p[i][j];
			}
			cout<<endl;
		}
}