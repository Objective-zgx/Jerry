#include<iostream>
#include<stdlib.h>
#include<string>
using namespace std;
int main()
{
	string p;
	cin>>p;
	const char *m=p.data();
    long long int x= (long long int)strtoul(m, NULL, 16);
	cout<<x;//FE65CDBA
}