#include<iostream>
using namespace std;
void f(int n){
	for(int i=1;i<=n&&i<=9;i++)
		{
			for(int j=0;j<=9&&j<=n;j++)
			{
				for(int k=0;k<=9&&j<=n;k++)
				{
					if(i+j+k+i+j==n)
						cout<<i<<j<<k<<j<<i<<endl;
				}
			}
	}
}
void s(int n){
	for(int i=1;i<=n&&i<=9;i++)
		{
			for(int j=0;j<=9&&j<=n;j++)
			{
				for(int k=0;k<=9&&k<=n;k++)
				{
					if(i+j+k+k+i+j==n)
						cout<<i<<j<<k<<k<<j<<i<<endl;
				}
			}
	}
}
void four(){
	for(int i=1;i<=9;i++)
		for(int j=0;j<10;j++)
			cout<<i<<j<<j<<i<<endl;
}
int main(){
	//int n;
	//cin>>n;
	//f(n);
	//s(n);
	four();
}