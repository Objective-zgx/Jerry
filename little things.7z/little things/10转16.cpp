#include<iostream>
#include<list>
using namespace std;

void fin(long int x){
	long int yy=1;
	char w=char(48);
	list<char> re;
	if(x!=0){
		while(x){
		yy=x%16;
		char r;
		if(yy<10) r=char(yy+48);
		else r=char(yy+55);
		if(x!=0)
		re.push_back(r);
		x/=16;
		}
	}else if(x==0) re.push_back(w);
	int si=re.size();
	while(re.size())
    {
		cout <<*re.rbegin();
		re.pop_back();
    }
}
int main(){	
	long int x;
	cin>>x;
	fin(x);
}