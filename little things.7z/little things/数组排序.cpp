#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	int *p;
	p= new int[n];
	for(int i=0;i<n;i++)
	{
		cin>>p[i];
	}
	for(int i=0;i<n;i++)
	{

		for(int j=i+1;j<n;j++)
		{
			int t;
			if(p[i]>p[j])
			{
				t=p[i];
				p[i]=p[j];
				p[j]=t;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<p[i]<<" ";
	}
	delete []p;
}