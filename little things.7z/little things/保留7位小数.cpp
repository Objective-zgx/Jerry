#include<stdio.h>
#include<iostream>
using namespace std;
int main(){
	int r;
	double s,pi=3.14159265358979323;
	cin>>r;
	s=r*r*pi;
	printf("%.7f",s);
}