#include<iostream>
#include<string>
using namespace std;
int main(){
	int n;
	cin>>n;

	char ch[26];
	ch[0]='A';
	for(int i=1;i<26;i++)
		ch[i]=ch[i-1]+1;

	if(n==1) cout<<"A";
	else{
		string *p=new string [n];
		p[0]="A";
		for(int i=1;i<n;i++)
		{	
			p[i]=p[i-1]+ch[i]+p[i-1];
		}
			cout<<p[n-1]<<endl;		
	}
}