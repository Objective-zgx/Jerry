#include<iostream>
using namespace std;
int main(){
	double v1,v2,s,t,l;
	cin>>v1>>v2>>t>>s>>l;
	int a=(l*(v1-v2)-(v1*t));
	int b=(v1*v2*s);
	int ns=0;
	if(a%b==0){
		ns=a/b;cout<<"������"<<endl;
	}
	else ns=a/b;
	int time1,time2;
	time1=l/v1+ns*s;
	time2=l/v2;
	if(time1<time2) cout<<"R"<<endl<<time1;
	else if(time1>time2) cout<<"T"<<endl<<time2;
	else cout<<"D"<<endl<<time1;
}