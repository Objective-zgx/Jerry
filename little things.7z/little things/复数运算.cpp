#include<iostream>
#include<iomanip>
#include<stdio.h>
#include<malloc.h>
using namespace std;
struct com{
	double ss;
	double xx;
};
com* add(com a,com b){
	com* c=(com*)malloc(sizeof(com));
	c->ss=a.ss+b.ss;
	c->xx=a.xx+b.xx;
	cout<<c->ss<<"+"<<c->xx<<"i";
	free(c);
	return c;
}
com* minu(com a,com b){
	com* c=(com*)malloc(sizeof(com));
	c->ss=a.ss-b.ss;
	c->xx=a.xx-b.xx;
	cout<<c->ss<<"+"<<c->xx<<"i";
	free(c);
	return c;
}
com* mul(com a,com b){
	com* c=(com*)malloc(sizeof(com));
	c->ss=a.ss*b.ss-a.xx*b.xx;
	c->xx=a.xx*b.ss+b.xx*a.ss;
	cout<<c->ss<<"+"<<c->xx<<"i";
	return c;
}
com* div(com a,com b){
	com* c=(com*)malloc(sizeof(com));
	c->ss=(a.ss*b.ss+a.xx*b.xx)/(b.ss*b.ss+b.xx*b.xx);
	c->xx=(-a.ss*b.xx+b.ss*a.xx)/(b.ss*b.ss+b.xx*b.xx);
	cout<<c->ss<<"+"<<c->xx<<"i";
	return c;
}
int main(){
	com a,b;
	double o,p,q,r;
	char x;
	x=getchar();
	cin>>o>>p>>q>>r;
	a.ss=o;a.xx=p;
	b.ss=q;b.xx=r;
	cout<<setiosflags(ios::fixed)<<setprecision(2);
	switch(x){
	case '+':add(a,b);break;
	case '-':minu(a,b);break;
	case'*':mul(a,b);break;
	case'/':div(a,b);break;
	}
	return 0;
}
